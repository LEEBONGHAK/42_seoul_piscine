#!/bin/zsh

clear
echo "\nOk, let's test your BSQ."
echo "\e[33m================================================================================\e[39m\n"
echo "\e[33mChecking Makefile\e[39m"
cd ../ && make clean && make fclean && make && make clean
echo "\n"
echo "\e[33m================================================================================\e[39m\n"
echo "\e[33mChecking Norminette\e[39m"
norminette -R CheckForbiddenSourceHeader
cd -
echo "\n"
echo "\e[33m================================================================================\e[39m\n"
echo "I am creating a 'results' directory where you'll find the results\n"
(rm -rf results 2>&1) > /dev/null
mkdir results > /dev/null 2>&1
sh test_table.sh
sh test_multi_arg.sh
sh test_inline.sh
sh bad_tests.sh
echo "\e[33m================================================================================\e[39m\n"
echo "Let's compare your results with ours...\n"

DIFF="$(diff -qrN results/ our_results/ | cut -f2 -d ' ')"


if [ -z "$DIFF" ]; then
	echo "		>>>>>> \e[32mSUCCESS\e[39m <<<<<<\n"
	echo "It looks the same, your BSQ passes all the tests !"
else
	echo "		>>>>>> \e[31mFAILURE\e[39m <<<<<<\n"
	echo -n "Do you want to see what test(s) are failing ? (Y/N) "
	
	while [[ $ANSWER != "Y" && $ANSWER != "y" && $ANSWER != "n" && $ANSWER != "N" ]]; do
		read ANSWER
		if [[ $ANSWER == "Y" || $ANSWER == "y" ]]; then
			echo "Ok, here are the solutions that differ :\n"
			echo "\e[33m--------------------------------------------------------------------------------\e[39m\n"
			echo "${DIFF}\n"
			echo "\e[33m--------------------------------------------------------------------------------\e[39m\n"
		elif [[ $ANSWER != "N" && $ANSWER != "n" ]]; then
			echo -n "Please only type Y or N "
		fi
	done
fi

diff -cN "results/" "our_results/"

echo "\n\e[33mAlright, it's over. You'll find the results in the 'results' directory."
